/**********************************************************************************************************************
 * \file DrvGtmTimer.c
 * \brief GTM TOM0 Ch1 기반 1ms 스케줄러 tick 드라이버 (자체 완결형)
 *
 * Clock chain:
 *   GTM Module Freq = fSOURCE / 2  (100 MHz)
 *   FXCLK1          = GCLK / 16 = 6,250,000 Hz
 *   period          = 6,250 ticks  → 1ms
 *
 * 메인 프로젝트와 달리 DrvPwm 없이 독립 동작:
 *   DrvGtmTimer_Init() 내부에서 GTM Enable + GCLK 설정 수행
 *********************************************************************************************************************/
#include "DrvGtmTimer.h"
#include "Gtm/Tom/Pwm/IfxGtm_Tom_Pwm.h"

/******************************************************************************/
/*                           Configuration                                    */
/******************************************************************************/
#define TIMER_PERIOD_TICKS  6250u    /* FXCLK1(6.25MHz) → 1ms */

/******************************************************************************/
/*                           Module Variables                                 */
/******************************************************************************/
volatile uint32 g_1ms_counter = 0u;

static IfxGtm_Tom_Pwm_Driver s_timer;

/******************************************************************************/
/*                           ISR (1ms tick)                                   */
/******************************************************************************/
IFX_INTERRUPT(gtmTimer_ISR, 0, DRVGTMTIMER_ISR_PRIORITY)
{
    IfxGtm_Tom_Ch_clearOneNotification(&MODULE_GTM.TOM[IfxGtm_Tom_0], IfxGtm_Tom_Ch_1);
    g_1ms_counter++;
}

/******************************************************************************/
/*                           Functions                                        */
/******************************************************************************/
void DrvGtmTimer_Init(void)
{
    Ifx_GTM *gtm  = &MODULE_GTM;
    float32  fMod = IfxGtm_Cmu_getModuleFrequency(gtm);

    /* GTM Enable + GCLK 설정 + FXCLK Enable (DrvPwm 없는 독립 동작용) */
    IfxGtm_enable(gtm);
    IfxGtm_Cmu_setGclkFrequency(gtm, fMod);
    IfxGtm_Cmu_enableClocks(gtm, IFXGTM_CMU_CLKEN_FXCLK);

    IfxGtm_Tom_Pwm_Config cfg;
    IfxGtm_Tom_Pwm_initConfig(&cfg, gtm);

    cfg.tom                      = IfxGtm_Tom_0;
    cfg.tomChannel               = IfxGtm_Tom_Ch_1;
    cfg.clock                    = IfxGtm_Tom_Ch_ClkSrc_cmuFxclk1;
    cfg.period                   = TIMER_PERIOD_TICKS;
    cfg.dutyCycle                = TIMER_PERIOD_TICKS / 2u;
    cfg.synchronousUpdateEnabled = TRUE;
    cfg.pin.outputPin            = NULL_PTR;
    cfg.interrupt.ccu0Enabled    = TRUE;
    cfg.interrupt.isrProvider    = IfxSrc_Tos_cpu0;
    cfg.interrupt.isrPriority    = DRVGTMTIMER_ISR_PRIORITY;

    IfxGtm_Tom_Pwm_init(&s_timer, &cfg);
}
