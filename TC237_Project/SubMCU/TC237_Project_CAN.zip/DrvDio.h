/**********************************************************************************************************************
 * \file DrvDio.h
 * \brief Digital I/O driver - LED control
 *********************************************************************************************************************/
#ifndef DRVDIO_H
#define DRVDIO_H

#include "Ifx_Types.h"

void DrvDio_Init(void);
void DrvDio_ToggleLed0(void);

#endif /* DRVDIO_H */
