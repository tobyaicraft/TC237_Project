/**********************************************************************************************************************
 * \file DrvDio.c
 * \brief Digital I/O driver — LED0 : P13.0 (active-low)
 *********************************************************************************************************************/
#include "DrvDio.h"
#include "IfxPort.h"

#define LED0_PORT   &MODULE_P13
#define LED0_PIN    0u

void DrvDio_Init(void)
{
    IfxPort_setPinMode(LED0_PORT, LED0_PIN, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinHigh(LED0_PORT, LED0_PIN);    /* LED OFF (active-low) */
}

void DrvDio_ToggleLed0(void)
{
    IfxPort_togglePin(LED0_PORT, LED0_PIN);
}
