/**********************************************************************************************************************
 * \file DrvGtmTimer.h
 * \brief GTM TOM0 Ch1 기반 1ms 스케줄러 tick 드라이버 (자체 완결형)
 *
 * - GTM 모듈 Enable + GCLK 설정 포함 (DrvPwm 의존성 없음)
 * - FXCLK1 = GCLK / 16,  period = 6,250 ticks → 정확히 1ms
 *********************************************************************************************************************/
#ifndef DRVGTMTIMER_H
#define DRVGTMTIMER_H

#include "Ifx_Types.h"

#define DRVGTMTIMER_ISR_PRIORITY    11U

extern volatile uint32 g_1ms_counter;

void DrvGtmTimer_Init(void);

#endif /* DRVGTMTIMER_H */
