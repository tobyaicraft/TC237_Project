/**********************************************************************************************************************
 * \file DrvIntc.h
 * \brief Interrupt controller driver - Watchdog disable
 *********************************************************************************************************************/
#ifndef DRVINTC_H
#define DRVINTC_H

void DrvIntc_Init(void);

#endif /* DRVINTC_H */
