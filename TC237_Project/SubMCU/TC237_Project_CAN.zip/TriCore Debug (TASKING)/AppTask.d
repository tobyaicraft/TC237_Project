AppTask.o :	../AppTask.c
../AppTask.c :
AppTask.o :	..\AppTask.h
..\AppTask.h :
AppTask.o :	..\DrvDio.h
..\DrvDio.h :
AppTask.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_Types.h" :
AppTask.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
AppTask.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h" :
AppTask.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
AppTask.o :	"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
AppTask.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Platform_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Platform_Types.h" :
AppTask.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h" :
AppTask.o :	..\DrvUart.h
..\DrvUart.h :
AppTask.o :	..\DrvCan.h
..\DrvCan.h :
