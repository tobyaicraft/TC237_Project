DrvUart.o :	../DrvUart.c
../DrvUart.c :
DrvUart.o :	..\DrvUart.h
..\DrvUart.h :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_Types.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
DrvUart.o :	"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Platform_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Platform_Types.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\\Tricore\\Compilers\Compilers.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\\Tricore\\Compilers\Compilers.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Asclin\Asc\IfxAsclin_Asc.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Asclin\Asc\IfxAsclin_Asc.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Asclin\Std\IfxAsclin.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Asclin\Std\IfxAsclin.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxAsclin_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxAsclin_cfg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxAsclin_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxAsclin_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxAsclin_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxAsclin_regdef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\Ifx_TypesReg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\Ifx_TypesReg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuCcu.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxScu_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxScu_cfg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_bf.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_bf.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_bf.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_bf.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_regdef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxCpu_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxCpu_cfg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_regdef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_regdef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_regdef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuCcu.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_regdef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\IfxScu_PinMap.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\IfxScu_PinMap.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Port\Std\IfxPort.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Port\Std\IfxPort.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxPort_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxPort_cfg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_regdef.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\Ifx_PinMap.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\Ifx_PinMap.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Src\Std\IfxSrc.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Src\Std\IfxSrc.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxSrc_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxSrc_cfg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Stm\Std\IfxStm.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Stm\Std\IfxStm.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxStm_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxStm_cfg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCbs_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCbs_reg.h" :
DrvUart.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCbs_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCbs_regdef.h" :
