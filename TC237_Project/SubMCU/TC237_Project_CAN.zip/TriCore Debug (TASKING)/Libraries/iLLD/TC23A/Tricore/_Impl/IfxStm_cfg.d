IfxStm_cfg.o :	../Libraries/iLLD/TC23A/Tricore/_Impl/IfxStm_cfg.c
../Libraries/iLLD/TC23A/Tricore/_Impl/IfxStm_cfg.c :
IfxStm_cfg.o :	..\Libraries\iLLD\TC23A\Tricore\_Impl\IfxStm_cfg.h
..\Libraries\iLLD\TC23A\Tricore\_Impl\IfxStm_cfg.h :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxStm_cfg.o :	"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Platform_Types.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_reg.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_regdef.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\Ifx_TypesReg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\Ifx_TypesReg.h" :
IfxStm_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h" :
