IfxScu_cfg.o :	../Libraries/iLLD/TC23A/Tricore/_Impl/IfxScu_cfg.c
../Libraries/iLLD/TC23A/Tricore/_Impl/IfxScu_cfg.c :
IfxScu_cfg.o :	..\Libraries\iLLD\TC23A\Tricore\_Impl\IfxScu_cfg.h
..\Libraries\iLLD\TC23A\Tricore\_Impl\IfxScu_cfg.h :
IfxScu_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h" :
IfxScu_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_bf.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_bf.h" :
IfxScu_cfg.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_bf.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_bf.h" :
