IfxCpu_Trap.o :	../Libraries/iLLD/TC23A/Tricore/Cpu/Trap/IfxCpu_Trap.c
../Libraries/iLLD/TC23A/Tricore/Cpu/Trap/IfxCpu_Trap.c :
IfxCpu_Trap.o :	..\Libraries\iLLD\TC23A\Tricore\Cpu\Trap\IfxCpu_Trap.h
..\Libraries\iLLD\TC23A\Tricore\Cpu\Trap\IfxCpu_Trap.h :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxCpu_Trap.o :	"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Platform_Types.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxCpu_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxCpu_cfg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_reg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxCpu_regdef.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\Ifx_TypesReg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\Ifx_TypesReg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_reg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxSrc_regdef.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_reg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_regdef.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_reg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxStm_regdef.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxScu_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxScu_cfg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_bf.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxScu_bf.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_bf.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_bf.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_reg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxFlash_regdef.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\IfxScu_PinMap.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\IfxScu_PinMap.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Port\Std\IfxPort.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Port\Std\IfxPort.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxPort_cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_Impl\IfxPort_cfg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_reg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_reg.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_regdef.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Sfr\\TC23A\\_Reg\IfxPort_regdef.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\Ifx_PinMap.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\_PinMap\Ifx_PinMap.h" :
IfxCpu_Trap.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
