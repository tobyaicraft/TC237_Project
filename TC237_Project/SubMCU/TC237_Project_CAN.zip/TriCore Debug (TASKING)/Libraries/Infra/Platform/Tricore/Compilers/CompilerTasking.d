CompilerTasking.o :	../Libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.c
../Libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.c :
CompilerTasking.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_Types.h" :
CompilerTasking.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
CompilerTasking.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Configurations\Ifx_Cfg.h" :
CompilerTasking.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
CompilerTasking.o :	"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"C:\Infineon\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
CompilerTasking.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Platform_Types.h" :
CompilerTasking.o :	"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\01_WorkPlace\\200_Aurix_Project\\TC237_Project_CAN\\Libraries\\iLLD\\TC23A\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
CompilerTasking.o :	..\Libraries\Infra\Platform\Tricore\Compilers\Compilers.h
..\Libraries\Infra\Platform\Tricore\Compilers\Compilers.h :
