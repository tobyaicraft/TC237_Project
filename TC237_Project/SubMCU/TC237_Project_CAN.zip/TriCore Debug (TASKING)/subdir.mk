################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
"../AppTask.c" \
"../Cpu0_Main.c" \
"../DrvCan.c" \
"../DrvDio.c" \
"../DrvGtmTimer.c" \
"../DrvIntc.c" \
"../DrvUart.c" \
"../Scheduler.c" 

COMPILED_SRCS += \
"AppTask.src" \
"Cpu0_Main.src" \
"DrvCan.src" \
"DrvDio.src" \
"DrvGtmTimer.src" \
"DrvIntc.src" \
"DrvUart.src" \
"Scheduler.src" 

C_DEPS += \
"./AppTask.d" \
"./Cpu0_Main.d" \
"./DrvCan.d" \
"./DrvDio.d" \
"./DrvGtmTimer.d" \
"./DrvIntc.d" \
"./DrvUart.d" \
"./Scheduler.d" 

OBJS += \
"AppTask.o" \
"Cpu0_Main.o" \
"DrvCan.o" \
"DrvDio.o" \
"DrvGtmTimer.o" \
"DrvIntc.o" \
"DrvUart.o" \
"Scheduler.o" 


# Each subdirectory must supply rules for building sources it contributes
"AppTask.src":"../AppTask.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"AppTask.o":"AppTask.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"Cpu0_Main.src":"../Cpu0_Main.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"Cpu0_Main.o":"Cpu0_Main.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"DrvCan.src":"../DrvCan.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"DrvCan.o":"DrvCan.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"DrvDio.src":"../DrvDio.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"DrvDio.o":"DrvDio.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"DrvGtmTimer.src":"../DrvGtmTimer.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"DrvGtmTimer.o":"DrvGtmTimer.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"DrvIntc.src":"../DrvIntc.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"DrvIntc.o":"DrvIntc.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"DrvUart.src":"../DrvUart.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"DrvUart.o":"DrvUart.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"Scheduler.src":"../Scheduler.c" "subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc23x "-fD:/01_WorkPlace/200_Aurix_Project/TC237_Project_CAN/TriCore Debug (TASKING)/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc23x -Y0 -N0 -Z0 -o "$@" "$<"
"Scheduler.o":"Scheduler.src" "subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean--2e-

clean--2e-:
	-$(RM) ./AppTask.d ./AppTask.o ./AppTask.src ./Cpu0_Main.d ./Cpu0_Main.o ./Cpu0_Main.src ./DrvCan.d ./DrvCan.o ./DrvCan.src ./DrvDio.d ./DrvDio.o ./DrvDio.src ./DrvGtmTimer.d ./DrvGtmTimer.o ./DrvGtmTimer.src ./DrvIntc.d ./DrvIntc.o ./DrvIntc.src ./DrvUart.d ./DrvUart.o ./DrvUart.src ./Scheduler.d ./Scheduler.o ./Scheduler.src

.PHONY: clean--2e-

