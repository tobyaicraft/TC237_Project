/**********************************************************************************************************************
 * \file AppTask.h
 * \brief Application task functions (1ms / 10ms / 100ms)
 *********************************************************************************************************************/
#ifndef APPTASK_H
#define APPTASK_H

void AppTask_1ms(void);
void AppTask_10ms(void);
void AppTask_100ms(void);

#endif /* APPTASK_H */
