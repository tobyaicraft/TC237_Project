/**********************************************************************************************************************
 * \file Cpu0_Main.c
 * \brief TC237 CAN Receiver — CAN ID=0x100 수신 → UART "XXXX\n" 전송
 *
 * 연결:
 *   CAN  : IDC10 X202 (CANH/CANL) ← TC237_Project 보드
 *   UART : X102 pin31(TX/P15.2), pin32(RX/P15.3) → PC USB-TTL
 *********************************************************************************************************************/
#include "Ifx_Types.h"
#include "IfxCpu.h"
#include "DrvIntc.h"
#include "DrvDio.h"
#include "DrvUart.h"
#include "DrvCan.h"
#include "DrvGtmTimer.h"
#include "Scheduler.h"

IfxCpu_syncEvent cpuSyncEvent = 0;

void core0_main(void)
{
    /* Watchdog 비활성화 */
    DrvIntc_Init();

    /* Driver 초기화 */
    DrvDio_Init();
    DrvUart_Init();
    DrvGtmTimer_Init();
    DrvCan_Init();

    /* 글로벌 인터럽트 Enable — 모든 초기화 완료 후 마지막 수행 */
    IfxCpu_enableInterrupts();

    /* CPU 동기화 */
    IfxCpu_emitEvent(&cpuSyncEvent);
    IfxCpu_waitEvent(&cpuSyncEvent, 1);

    DrvUart_SendString("=== TC237 CAN Receiver ===\r\n");
    DrvUart_SendString("CAN ID=0x100, 500kbps -> UART 115200\r\n");
    DrvUart_SendString("Ready.\r\n\r\n");

    while (1)
    {
        Scheduler_Run();
    }
}
