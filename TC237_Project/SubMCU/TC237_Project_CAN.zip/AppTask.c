/**********************************************************************************************************************
 * \file AppTask.c
 * \brief Application task implementations (CAN Receiver Board)
 *
 * Task_1ms   : UART echo
 * Task_10ms  : CAN RX 폴링 → 새 데이터 수신 시 UART로 "XXXX\n" 전송
 * Task_100ms : LED0 토글 (수신 동작 표시)
 *********************************************************************************************************************/
#include "AppTask.h"
#include "DrvDio.h"
#include "DrvUart.h"
#include "DrvCan.h"

/******************************************************************************/
/*                           1ms Task                                         */
/******************************************************************************/
void AppTask_1ms(void)
{
    uint8 rxByte;
    while (DrvUart_ReceiveByte(&rxByte))
    {
        DrvUart_SendByte(rxByte);
    }
}

/******************************************************************************/
/*                           10ms Task                                        */
/******************************************************************************/
void AppTask_10ms(void)
{
    uint16 adcValue;

    /* CAN 수신 데이터 확인 → UART 전송 (Python 오실로스코프 호환 포맷 "XXXX\n") */
    if (DrvCan_ReceiveUint16(&adcValue))
    {
        DrvUart_SendUint16(adcValue);
    }
}

/******************************************************************************/
/*                           100ms Task                                       */
/******************************************************************************/
void AppTask_100ms(void)
{
    DrvDio_ToggleLed0();
}
