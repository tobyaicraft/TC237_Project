/**********************************************************************************************************************
 * \file DrvCan.c
 * \brief MultiCAN Node0 RX 드라이버
 *
 * Message Object 0 : RX, ID=0x100, AccMask=0x7FF (정확 일치), DLC=2
 * CAN 메시지 수신 시 ISR(우선순위 10) 호출 → s_rxData 저장, s_rxFlag 세트
 * AppTask_10ms 에서 DrvCan_ReceiveUint16() 폴링 → DrvUart_SendUint16() 전달
 *********************************************************************************************************************/
#include "DrvCan.h"
#include "Multican/Can/IfxMultican_Can.h"
#include "_PinMap/IfxMultican_PinMap.h"

/******************************************************************************/
/*                           Module Variables                                 */
/******************************************************************************/
static IfxMultican_Can        s_can;
static IfxMultican_Can_Node   s_node;
static IfxMultican_Can_MsgObj s_rxMsgObj;

static volatile uint16  s_rxData = 0u;
static volatile boolean s_rxFlag = FALSE;

/******************************************************************************/
/*                           ISR                                              */
/******************************************************************************/
IFX_INTERRUPT(DrvCan_RxISR, 0, DRVCAN_RX_PRIORITY)
{
    IfxMultican_Message rxMsg;
    IfxMultican_Can_MsgObj_readMessage(&s_rxMsgObj, &rxMsg);
    /* dataLow(data[0])에 ADC 값(0~4095) 저장됨 */
    s_rxData = (uint16)(rxMsg.data[0] & 0x0FFFu);
    s_rxFlag = TRUE;
}

/******************************************************************************/
/*                           Functions                                        */
/******************************************************************************/
void DrvCan_Init(void)
{
    /* ── CAN 모듈 초기화 + 인터럽트 우선순위 설정 ── */
    IfxMultican_Can_Config canCfg;
    IfxMultican_Can_initModuleConfig(&canCfg, &MODULE_CAN);
    /* SrcId 0 → CPU0, 우선순위 10 */
    canCfg.nodePointer[0].priority      = DRVCAN_RX_PRIORITY;
    canCfg.nodePointer[0].typeOfService = IfxSrc_Tos_cpu0;
    IfxMultican_Can_initModule(&s_can, &canCfg);

    /* ── Node 0: P20.7 RX, P20.8 TX, 500 kbps ── */
    IfxMultican_Can_NodeConfig nodeCfg;
    IfxMultican_Can_Node_initConfig(&nodeCfg, &s_can);
    nodeCfg.nodeId    = IfxMultican_NodeId_0;
    nodeCfg.baudrate  = CAN_BAUDRATE;
    nodeCfg.rxPin     = &IfxMultican_RXD0B_P20_7_IN;
    nodeCfg.rxPinMode = IfxPort_InputMode_pullUp;
    nodeCfg.txPin     = &IfxMultican_TXD0_P20_8_OUT;
    nodeCfg.txPinMode = IfxPort_OutputMode_pushPull;
    IfxMultican_Can_Node_init(&s_node, &nodeCfg);

    /* ── RX Message Object 0 ── */
    IfxMultican_Can_MsgObjConfig rxCfg;
    IfxMultican_Can_MsgObj_initConfig(&rxCfg, &s_node);
    rxCfg.msgObjId            = 0u;
    rxCfg.messageId           = CAN_MSG_ID;
    rxCfg.acceptanceMask      = 0x7FFu;        /* 11-bit 전체 일치 */
    rxCfg.frame               = IfxMultican_Frame_receive;
    rxCfg.control.messageLen  = IfxMultican_DataLengthCode_2;
    rxCfg.rxInterrupt.enabled = TRUE;
    rxCfg.rxInterrupt.srcId   = IfxMultican_SrcId_0;
    IfxMultican_Can_MsgObj_init(&s_rxMsgObj, &rxCfg);
}

boolean DrvCan_ReceiveUint16(uint16 *value)
{
    if (s_rxFlag)
    {
        *value   = s_rxData;
        s_rxFlag = FALSE;
        return TRUE;
    }
    return FALSE;
}
