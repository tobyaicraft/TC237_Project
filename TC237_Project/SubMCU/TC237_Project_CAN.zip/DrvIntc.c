/**********************************************************************************************************************
 * \file DrvIntc.c
 * \brief CPU / Safety Watchdog 비활성화
 *********************************************************************************************************************/
#include "DrvIntc.h"
#include "IfxScuWdt.h"

void DrvIntc_Init(void)
{
    IfxScuWdt_disableCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());
    IfxScuWdt_disableSafetyWatchdog(IfxScuWdt_getSafetyWatchdogPassword());
}
