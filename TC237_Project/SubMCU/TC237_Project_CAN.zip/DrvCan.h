/**********************************************************************************************************************
 * \file DrvCan.h
 * \brief MultiCAN Node0 RX 드라이버 (CAN 수신 → UART 전달)
 *
 * TX : P20.8 (IfxMultican_TXD0_P20_8_OUT) → TLE7250GVIO → IDC10 X202
 * RX : P20.7 (IfxMultican_RXD0B_P20_7_IN) ← TLE7250GVIO ← IDC10 X202
 * Baudrate : 500 kbps  |  메시지 ID : 0x100  |  DLC : 2 bytes
 * ISR 우선순위 : 10  (GTM Timer=11, UART TX=3, RX=4 와 충돌 없음)
 *********************************************************************************************************************/
#ifndef DRVCAN_H
#define DRVCAN_H

#include "Ifx_Types.h"

/* 주의: 괄호 없이 정의 — 인터럽트 벡터 섹션 이름 생성에 사용됨 */
#define DRVCAN_RX_PRIORITY  10

#define CAN_BAUDRATE    500000u    /* 500 kbps */
#define CAN_MSG_ID      0x100u     /* ADC 데이터 표준 프레임 ID */

void    DrvCan_Init(void);
boolean DrvCan_ReceiveUint16(uint16 *value);   /* 새 수신 데이터 있으면 TRUE 반환 */

#endif /* DRVCAN_H */
