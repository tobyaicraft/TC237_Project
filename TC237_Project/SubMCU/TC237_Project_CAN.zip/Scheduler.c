/**********************************************************************************************************************
 * \file Scheduler.c
 * \brief 1ms GTM tick 기반 협력형 스케줄러 (modulo 분주)
 *********************************************************************************************************************/
#include "Scheduler.h"
#include "DrvGtmTimer.h"
#include "AppTask.h"

void Scheduler_Run(void)
{
    static uint32 last_counter = 0u;
    uint32        now = g_1ms_counter;

    if (now == last_counter)
    {
        return;
    }
    last_counter = now;

    if ((now %   1U) == 0U) AppTask_1ms();
    if ((now %  10U) == 0U) AppTask_10ms();
    if ((now % 100U) == 0U) AppTask_100ms();
}
